import UIKit

var sayi1=0
var sayi2=0

for sayi in 1...1000{
    if((sayi*3)<1000){
        sayi1+=(sayi*3)
    }
    if((sayi*5)<1000){
        sayi2+=(sayi*5)
    }

}
print(sayi1)
print(sayi2)
print(sayi1+sayi2)

//MARK: İkinci soru çözümü


var birincisayi=0
var ikincisayi=1
var toplam = 0
var ciftSayilar=0

while(toplam<4000000){
    toplam = birincisayi + ikincisayi
    birincisayi = ikincisayi
    ikincisayi = toplam
    if(toplam%2==0){
        ciftSayilar=ciftSayilar+toplam
    }
}
print(ciftSayilar)


//MARK: Ücüncü soru
//Bir arkadaştan yardım aldım bu soru da discord üzerinden
var number = 13195
var prime = 2
var largest = 0
while number != 1 {
    if number % prime == 0{
        largest = prime
        number /= prime
    } else {
        prime += 1
        
    }
}
print(largest)

